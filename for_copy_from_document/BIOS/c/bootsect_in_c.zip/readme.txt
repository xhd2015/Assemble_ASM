read HowToUse.md
